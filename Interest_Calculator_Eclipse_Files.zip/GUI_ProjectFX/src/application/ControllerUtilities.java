package application;

import javafx.event.ActionEvent;

public class ControllerUtilities {

	public String calculateSimpleInterest( double principal , double interest, int years) {

//		String principalString =  principalField.getText();
//		String interestString  =  interestField.getText() ;
		
		System.out.println("CalulcateSimpleInterest");
		StringBuffer displayText = new StringBuffer("");
//		int years = (int)yearSlider.getValue();
		
//		System.out.println("SimpleInterest clicked");
//		System.out.println("principal : " + principal  );
//		System.out.println("interest : " + interestString );
//		System.out.println("Years : " + years  );
//		
//		displayText.append("principal : " + principalString + "\n" );
//		displayText.append("interest : " + interestString + "\n");
//		displayText.append("Years : " + yearsDisplayed + "\n");
		
		double calculation ;
//		double interestVal = Double.parseDouble(interestString);
//		Double principalVal = Double.parseDouble(principalString);

		
		
		//Generates a list of calculations for each year.
		for(int i = 1; i <= years; i++) {
			calculation =  principal + (principal * ( interest /100) * i);
			System.out.println("Year " + i + " : $" + String.format("%.2f", principal) + "--> $" + String.format("%.2f", calculation) + "\n");
			displayText.append("Year " + i + " : $" + String.format("%.2f", principal) + "--> $" + String.format("%.2f", calculation) + "\n");
			// + String.format("%.2f", principal) + "-->" + String.format("%.2f", calculation) + "\n"
		}
		
		return displayText.toString();
	}
	
	public String calculateCompoundInterest( double principal , double interest, int years) {

		System.out.println("CalulcateCompoundInterest");
		StringBuffer displayText = new StringBuffer("");
		
		double calculation ;

		//Generates a list of calculations for each year.
		
		
		for(int i = 1; i <= years; i++) {
			calculation =  principal * Math.pow(1 + (interest/100), i) ;
			System.out.println("Year " + i + " : $" + String.format("%.2f", principal) + "--> $" + String.format("%.2f", calculation) + "\n");
			displayText.append("Year " + i + " : $" + String.format("%.2f", principal) + "--> $" + String.format("%.2f", calculation) + "\n");
		}
		
		return displayText.toString();
	}
	
	public String calculateBothInterests( double principal , double interest, int years) {

		System.out.println("CalulcateBothInterest");
		StringBuffer displayText = new StringBuffer("");
		
		double simpleCalculation ;
		double compoundCalculation ;
		
		//Generates a list of calculations for each year.
		for(int i = 1; i <= years; i++) {
			simpleCalculation =  principal + (principal * (interest/100) * i);
			compoundCalculation =  principal * Math.pow(1 + (interest/100), i) ;
			System.out.print("Year " + i + " : $" + String.format("%.2f", principal) + "--> $" + String.format("%.2f", simpleCalculation) + "\n");
			System.out.println("  :  $" +  String.format("%.2f", compoundCalculation) );
			displayText.append("Year " + i + " : $" + String.format("%.2f", principal) + "--> $" + String.format("%.2f", simpleCalculation) );
			displayText.append("  :  $" +  String.format("%.2f", compoundCalculation) + "\n");
			
			// + String.format("%.2f", principal) + "-->" + String.format("%.2f", calculation) + "\n"
		}
		
		return displayText.toString();
	}
	
}
