package application;
	
import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;


public class InterestTableGUI extends Application {
	
	
	public static void main(String[] args) {
		Application.launch(args);
	}
	
	@Override
	public void start(Stage stage) {
		
		
		//BroCode's Stage argument is called "stage"
			
		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("Main.fxml") );
			Scene scene = new Scene(root);
			stage.centerOnScreen();
			stage.setResizable(false);
			
			
			Image windowIcon = new Image("icon.png");
			
			stage.getIcons().add(windowIcon);
			stage.setTitle("InterestTableGUI :3");
			
			
			stage.setScene(scene);
			stage.show();
			
			
			//Upon button pressing
			//take in input
			//		take in whatever's been typed in the GUI box.
			//
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
//		try {
//			BorderPane root = new BorderPane();
//			Scene scene = new Scene(root,400,400);
//			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
//			stage.setScene(scene);
//			stage.show();
//			
//			Button button = new Button("Compute");
//			
//			
//		
//				
//		} catch(Exception e) {
//			e.printStackTrace();
//		}
		
	}
	
	
	
}
