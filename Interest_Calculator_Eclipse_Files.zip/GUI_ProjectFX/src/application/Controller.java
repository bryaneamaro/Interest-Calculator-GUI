package application;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.ResourceBundle.Control;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.*;

public class Controller implements Initializable {

	@FXML
	private Button simpleInterest_button;
	@FXML
	private Button compoundInterest_button;
	@FXML
	private Button bothInterests_button;
	
	
	@FXML
	private TextField principalField;
	
	@FXML
	private TextField interestField;
	
	@FXML
	private Slider yearSlider;
	
	@FXML
	private TextField displayYearsBox;
	
	@FXML
	private TextArea textDisplay;
	
	
	
	
	@FXML
	private AnchorPane scenePane;
	
	String yearsDisplayed;
	Stage stage;
	
	public void clickedSimpleButton( ActionEvent event ) {
		String principalString =  principalField.getText();
		String interestString  =  interestField.getText() ;
		
		StringBuffer displayText = new StringBuffer("");
		int years = (int)yearSlider.getValue();
		
		System.out.println("SimpleInterest clicked");
		System.out.println("principal : " + principalString  );
		System.out.println("interest : " + interestString );
		System.out.println("Years : " + years  );
		
		displayText.append("principal : " + principalString + "\n" );
		displayText.append("interest : " + interestString + "\n");
		displayText.append("Years : " + yearsDisplayed + "\t\t   Simple Interest\n");
		
//		double calculation ;
		double interestVal = Double.parseDouble(interestString);
		double principalVal = Double.parseDouble(principalString);

		ControllerUtilities helper = new ControllerUtilities();
		
		String calculationText = helper.calculateSimpleInterest(principalVal , interestVal, years  );
		displayText.append(calculationText);
		textDisplay.setText( displayText.toString() );
	}
	public void clickedCompoundButton(ActionEvent event) {
		
		String principalString =  principalField.getText();
		String interestString  =  interestField.getText() ;
		
		StringBuffer displayText = new StringBuffer("");
		int years = (int)yearSlider.getValue();
		
		System.out.println("CompoundInterest clicked");
		System.out.println("principal : " + principalString  );
		System.out.println("interest : " + interestString );
		System.out.println("Years : " + years  );
		
		displayText.append("principal : " + principalString + "\n" );
		displayText.append("interest : " + interestString + "\n");
		displayText.append("Years : " + yearsDisplayed + "\t\t   Compound Interest\n");
		
//		double calculation ;
		double interestVal = Double.parseDouble(interestString);
		double principalVal = Double.parseDouble(principalString);

		ControllerUtilities helper = new ControllerUtilities();
		
		String calculationText = helper.calculateCompoundInterest(principalVal , interestVal, years  );
		displayText.append(calculationText);
		textDisplay.setText( displayText.toString() );
	}
	
	public void clickedBothButton(ActionEvent event) {
		
		String principalString =  principalField.getText();
		String interestString  =  interestField.getText() ;
		
		StringBuffer displayText = new StringBuffer("");
		int years = (int)yearSlider.getValue();
		
		System.out.println("BothInterest clicked");
		System.out.println("principal : " + principalString  );
		System.out.println("interest : " + interestString );
		System.out.println("Years : " + years  );
		
		displayText.append("principal : " + principalString + "\n" );
		displayText.append("interest : " + interestString + "\n");
		displayText.append("Years : " + yearsDisplayed + "\t\t Simple Interest : Compound Interest \n");
		
//		double calculation ;
		double interestVal = Double.parseDouble(interestString);
		double principalVal = Double.parseDouble(principalString);

		ControllerUtilities helper = new ControllerUtilities();
		
		String calculationText = helper.calculateBothInterests(principalVal , interestVal, years  );
		displayText.append(calculationText);
		textDisplay.setText( displayText.toString() );
	}
	
	
	
	
	public void updateDisplayBox( ActionEvent event ) {
	
		System.out.println("Dragging Shit");
		
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
		yearsDisplayed =  (int)yearSlider.getValue() + " ";
		displayYearsBox.setText( yearsDisplayed.toString() );
		
		yearSlider.valueProperty().addListener(new ChangeListener<Number>() { 
			
			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldNumber, Number newNumber) {
				
				try {
					yearsDisplayed =  (int)yearSlider.getValue() + " ";
					displayYearsBox.setText( yearsDisplayed.toString() );
				} catch (Error e) {
					System.out.println("erorr here");
				}
				
				
				
			}			
			
		});
		
	}
	
}
